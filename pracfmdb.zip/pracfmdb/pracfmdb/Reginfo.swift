//
//  Reginfo.swift
//  pracfmdb
//
//  Created by Yogesh Patel on 14/11/17.
//  Copyright © 2017 Yogesh Patel. All rights reserved.
//

import UIKit

class Reginfo: NSObject {
    var id:String = String()
    var name:String = String()
    var username:String = String()
    var email:String = String()
    var password:String = String()
}
