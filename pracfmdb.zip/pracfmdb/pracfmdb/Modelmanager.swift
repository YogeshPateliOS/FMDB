//
//  Modelmanager.swift
//  pracfmdb
//
//  Created by Yogesh Patel on 14/11/17.
//  Copyright © 2017 Yogesh Patel. All rights reserved.
//

import UIKit
var sharedinstance = Modelmanager()
class Modelmanager: NSObject {

    var database:FMDatabase? = nil
    
    class func getinstance() -> Modelmanager
    {
        if sharedinstance.database == nil
        {
            sharedinstance.database = FMDatabase(path: Util.getpath("Database.db"))
        }
        return sharedinstance
    }
    
    func addregdata(_ reginfo:Reginfo) ->Bool
    {
        sharedinstance.database?.open()
        let isinserted = sharedinstance.database?.executeUpdate("INSERT INTO reginfo (name, username, email, password) VALUES(?,?,?,?)", withArgumentsIn: [reginfo.name, reginfo.username, reginfo.email, reginfo.password])
        sharedinstance.database?.close()
        return isinserted!
    }
    
    func updateregdata (_ reginfo: Reginfo) -> Bool
    {
        sharedinstance.database?.open()
        let isupdated = sharedinstance.database?.executeUpdate("UPDATE reginfo SET name=?, username=?, email=?, password=? WHERE id=?" , withArgumentsIn: [reginfo.name, reginfo.username, reginfo.email, reginfo.password, reginfo.id])
        sharedinstance.database?.close()
        return isupdated!
    }
    func deleteregdata(_ reginfro: Reginfo) -> Bool
    {
        sharedinstance.database?.open()
        let isdeleted = sharedinstance.database?.executeUpdate("DELETE FROM reginfo WHERE id=?", withArgumentsIn: [reginfro.id])
        sharedinstance.database?.close()
        return isdeleted!
    }
    
    func getallregdata() -> NSMutableArray
    {
        let mainarr :NSMutableArray = NSMutableArray()
        sharedinstance.database?.open()
        do
        {
            let resultset:FMResultSet! = try sharedinstance.database?.executeQuery("SELECT * FROM reginfo", values: nil)
            if resultset != nil
            {
                while resultset.next()
                {
                    let reginfo1:Reginfo = Reginfo()
                    reginfo1.id = resultset.string(forColumn: "id")!
                    reginfo1.name = resultset.string(forColumn: "name")!
                    reginfo1.username = resultset.string(forColumn: "username")!
                    reginfo1.email = resultset.string(forColumn: "email")!
                    reginfo1.password = resultset.string(forColumn: "password")!
                    mainarr.add(reginfo1)
                }
            }
        }
        catch
        {
            print("Failde: \(error.localizedDescription)")
        }
        sharedinstance.database?.close()
        return mainarr
    }
}
