//
//  TableViewCell.swift
//  pracfmdb
//
//  Created by Yogesh Patel on 14/11/17.
//  Copyright © 2017 Yogesh Patel. All rights reserved.
//

import UIKit

class TableViewCell: UITableViewCell {
    @IBOutlet var lblname: UILabel!
    
    @IBOutlet var lblusername: UILabel!
    
    @IBOutlet var lblemail: UILabel!
    
    @IBOutlet var lblpassword: UILabel!
    
    @IBOutlet var btnedit: UIButton!
    @IBOutlet var btndelete: UIButton!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

  
    
}
